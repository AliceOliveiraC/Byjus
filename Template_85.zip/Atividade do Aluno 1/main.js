
// Defina um array vazio que armazena os nomes dos alunos.
    
function submit()
{
    //defina um array que guarda todos os nomes dos alunos

    //defina loop for para buscar o valor da caixa de entrada e guardar no array.

    //Imprima o valor de nameOfTheStudent na tela do console

   //length do array e guardamos dentro da variável

    //vamos imprimir a length do array na tela do console

    //Repetimos a nameOfTheStudentArray

    //imprima displayStudentArray na tela do console

    //Imprima esse displayStudentArray dentro do elemento HTML.

    //Defina uma variável e armazene displayStudentArray com uma função join

    //imprima o array e verifique o resultado

    //Imprima removeCommas dentro do elemento HTML
    
    //Ocultar botão Enviar 

}
