
//ADICIONE OS LINKS DO SEU APP FIREBASE



// Inicializar Firebase
   firebase.initializeApp(firebaseConfig);



// Adicionar a função para adicionar usuário 